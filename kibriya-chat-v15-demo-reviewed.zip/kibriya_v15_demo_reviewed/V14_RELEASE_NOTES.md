# Kibriya Chat V14 Commercial

## Agency & Host Business Layer
- Agency member model with roles: owner, manager, agent, host.
- Host profiles with targets and activation state.
- Daily host performance aggregates.
- Owner-only agency creation and member assignment APIs.
- Agency detail API with 30-day host performance.
- Host leaderboard API for commercial operations.
- Economy summary API for daily/monthly ledger visibility.
- Admin dashboard sections for host ranking and economy summary.

## Important
This release adds operational data structures and dashboards. It does not introduce real-money gambling, cash-out, or payment processing.

## Database
Apply `server/sql/013_agency_host_commercial.sql` after the existing migrations.
