# Kibriya Chat V15 Business

## New production-oriented business layer
- Host dashboard API: `/api/host/me/dashboard`
- Host goals with weekly periods and rewards.
- Business events with publish/pause/draft lifecycle.
- Moderation action audit trail.
- Agency performance analytics for the last 30 days.
- Admin endpoints for goal/event/moderation management.
- New SQL migration: `014_v15_business_growth.sql`.

## Commercial focus
This release prioritizes measurable business operations over cosmetic feature count: host performance, agency performance, events, goals, rewards, and moderation history.

## Verification
Run:
- `npm run check` inside `server/`
- `bash scripts/full_audit.sh`
- Apply SQL migrations before enabling the new endpoints.
