# Kibriya Chat v10.3 — Owner Economy & VIP Policy

## Owner-only economy
- The economy dashboard is protected server-side for the configured Owner account.
- It shows virtual economy totals, active gifts, VIP/SVIP counts and the configured distribution policy.
- Distribution is based on the net distributable pool after applicable store/payment fees and approved external-service costs.
- Default allocation: Owner 40%, hosts 25%, agencies 15%, rewards 10%, operating reserve 10%.
- Percentages must total exactly 100%.

## Policy period
The policy is issued for one year and reviewed/renewed annually. A version, effective date and expiry date are stored in the database. This avoids locking the business into a fixed ten-year economic rule while still giving users a clear published period.

## VIP 0–15
VIP 0 is the standard account. VIP 1–15 are cumulative: each level inherits prior benefits and adds its own upgrade. The exact thresholds and benefits are stored in `vip_levels` and displayed in the Membership screen.

## Important production note
This is an in-app commercial policy/configuration, not a government registration certificate or legal opinion. Before launch, the final Terms, Privacy Policy, refunds, creator/agency contracts, taxes and payment wording should be reviewed for the countries in which the service operates.
