-- V14 Commercial: agency + host performance layer
CREATE TABLE IF NOT EXISTS agency_members (
  agency_id UUID NOT NULL REFERENCES agencies(id) ON DELETE CASCADE,
  user_id UUID NOT NULL REFERENCES users(id) ON DELETE CASCADE,
  role VARCHAR(24) NOT NULL DEFAULT 'host',
  status VARCHAR(20) NOT NULL DEFAULT 'active',
  joined_at TIMESTAMPTZ NOT NULL DEFAULT now(),
  PRIMARY KEY (agency_id,user_id)
);
CREATE TABLE IF NOT EXISTS host_profiles (
  user_id UUID PRIMARY KEY REFERENCES users(id) ON DELETE CASCADE,
  display_title VARCHAR(120),
  level INT NOT NULL DEFAULT 1,
  target_minutes INT NOT NULL DEFAULT 600,
  target_gifts BIGINT NOT NULL DEFAULT 0,
  active BOOLEAN NOT NULL DEFAULT TRUE,
  created_at TIMESTAMPTZ NOT NULL DEFAULT now(),
  updated_at TIMESTAMPTZ NOT NULL DEFAULT now()
);
CREATE TABLE IF NOT EXISTS host_daily_stats (
  user_id UUID NOT NULL REFERENCES users(id) ON DELETE CASCADE,
  day DATE NOT NULL,
  room_minutes INT NOT NULL DEFAULT 0,
  gifts_received BIGINT NOT NULL DEFAULT 0,
  gift_coins BIGINT NOT NULL DEFAULT 0,
  rooms_hosted INT NOT NULL DEFAULT 0,
  unique_visitors INT NOT NULL DEFAULT 0,
  PRIMARY KEY(user_id,day)
);
CREATE INDEX IF NOT EXISTS idx_agency_members_agency ON agency_members(agency_id,status);
CREATE INDEX IF NOT EXISTS idx_host_daily_day ON host_daily_stats(day DESC);
CREATE INDEX IF NOT EXISTS idx_host_daily_coins ON host_daily_stats(gift_coins DESC);
INSERT INTO host_profiles(user_id)
SELECT id FROM users WHERE id IN (SELECT owner_id FROM agencies)
ON CONFLICT (user_id) DO NOTHING;
