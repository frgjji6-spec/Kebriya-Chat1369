-- V15 Business: host goals, events, moderation actions and agency monthly snapshots
CREATE TABLE IF NOT EXISTS host_goals (
  id BIGSERIAL PRIMARY KEY,
  user_id UUID NOT NULL REFERENCES users(id) ON DELETE CASCADE,
  goal_key VARCHAR(60) NOT NULL,
  title VARCHAR(160) NOT NULL,
  target_value BIGINT NOT NULL DEFAULT 0,
  reward_coins BIGINT NOT NULL DEFAULT 0,
  reward_xp INT NOT NULL DEFAULT 0,
  period_start DATE NOT NULL DEFAULT current_date,
  period_end DATE NOT NULL DEFAULT current_date + 6,
  progress BIGINT NOT NULL DEFAULT 0,
  claimed BOOLEAN NOT NULL DEFAULT FALSE,
  active BOOLEAN NOT NULL DEFAULT TRUE,
  created_at TIMESTAMPTZ NOT NULL DEFAULT now()
);
CREATE INDEX IF NOT EXISTS idx_host_goals_user_period ON host_goals(user_id,period_end DESC);
CREATE TABLE IF NOT EXISTS business_events (
  id BIGSERIAL PRIMARY KEY,
  title VARCHAR(180) NOT NULL,
  description TEXT,
  event_type VARCHAR(40) NOT NULL DEFAULT 'community',
  starts_at TIMESTAMPTZ,
  ends_at TIMESTAMPTZ,
  target_value BIGINT NOT NULL DEFAULT 0,
  reward_coins BIGINT NOT NULL DEFAULT 0,
  reward_xp INT NOT NULL DEFAULT 0,
  status VARCHAR(20) NOT NULL DEFAULT 'draft',
  created_by UUID REFERENCES users(id),
  created_at TIMESTAMPTZ NOT NULL DEFAULT now()
);
CREATE INDEX IF NOT EXISTS idx_business_events_dates ON business_events(starts_at,ends_at);
CREATE TABLE IF NOT EXISTS moderation_actions (
  id BIGSERIAL PRIMARY KEY,
  moderator_id UUID REFERENCES users(id),
  target_user_id UUID REFERENCES users(id),
  room_id UUID REFERENCES rooms(id),
  action VARCHAR(40) NOT NULL,
  reason VARCHAR(500),
  metadata JSONB NOT NULL DEFAULT '{}'::jsonb,
  created_at TIMESTAMPTZ NOT NULL DEFAULT now()
);
CREATE INDEX IF NOT EXISTS idx_moderation_actions_created ON moderation_actions(created_at DESC);
CREATE TABLE IF NOT EXISTS agency_monthly_snapshots (
  id BIGSERIAL PRIMARY KEY,
  agency_id UUID NOT NULL REFERENCES agencies(id) ON DELETE CASCADE,
  month_start DATE NOT NULL,
  members INT NOT NULL DEFAULT 0,
  room_minutes BIGINT NOT NULL DEFAULT 0,
  gifts_received BIGINT NOT NULL DEFAULT 0,
  gift_coins BIGINT NOT NULL DEFAULT 0,
  created_at TIMESTAMPTZ NOT NULL DEFAULT now(),
  UNIQUE(agency_id,month_start)
);
