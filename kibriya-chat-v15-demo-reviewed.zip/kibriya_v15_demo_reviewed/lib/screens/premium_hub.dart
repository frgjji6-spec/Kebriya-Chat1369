import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import '../core/providers.dart';
import '../core/theme.dart';

class PremiumHubScreen extends ConsumerStatefulWidget {
  const PremiumHubScreen({super.key});
  @override ConsumerState<PremiumHubScreen> createState() => _PremiumHubScreenState();
}

class _PremiumHubScreenState extends ConsumerState<PremiumHubScreen> {
  late Future<List<Map<String,dynamic>>> _load;
  @override void initState(){super.initState(); _load=_loadData();}
  Future<List<Map<String,dynamic>>> _loadData() async {
    final api=ref.read(apiProvider);
    final results=await Future.wait([
      api.wallet(), api.wealth(), api.levels(), api.referrals(), api.notifications(), api.platformHealth(),
    ]);
    return results.map((e)=>Map<String,dynamic>.from(e as Map)).toList();
  }
  void _refresh(){setState(()=>_load=_loadData());}
  @override Widget build(BuildContext context)=>Scaffold(
    appBar: AppBar(title: const Text('مركز كبرياء Premium',style: TextStyle(fontWeight: FontWeight.w900)),actions:[IconButton(onPressed:_refresh,icon:const Icon(Icons.refresh))]),
    body: FutureBuilder<List<Map<String,dynamic>>>(future:_load,builder:(context,s){
      if(s.connectionState==ConnectionState.waiting)return const Center(child:CircularProgressIndicator());
      if(s.hasError)return Center(child:Padding(padding:const EdgeInsets.all(24),child:Column(mainAxisSize:MainAxisSize.min,children:[const Icon(Icons.cloud_off,size:52),const SizedBox(height:12),
      Text('تعذر تحميل مركز Premium'),const SizedBox(height:8),Text('${s.error}',textAlign:TextAlign.center),const SizedBox(height:16),FilledButton(onPressed:_refresh,child:const Text('إعادة المحاولة'))])));
      final x=s.data!; final wallet=x[0], wealth=x[1], levels=x[2], refs=x[3], notes=x[4], health=x[5];
      return RefreshIndicator(onRefresh:()async=>_refresh(),child:ListView(padding:const EdgeInsets.all(16),children:[
        Container(padding:const EdgeInsets.all(18),decoration:BoxDecoration(borderRadius:BorderRadius.circular(24),gradient:const LinearGradient(colors:[KibriyaColors.wine,KibriyaColors.surface2])),child:const Column(crossAxisAlignment:CrossAxisAlignment.start,children:[Text('منصة اجتماعية صوتية متكاملة',style:TextStyle(fontSize:23,fontWeight:FontWeight.w900)),SizedBox(height:8),Text('غرف صوتية • هدايا • VIP • عائلات • ألعاب • اقتصاد رقمي',style:TextStyle(color:KibriyaColors.muted))])),
        const SizedBox(height:16),
        _section('الاقتصاد',[
          _metric('🪙 العملات',wallet['coins']??wallet['balance']??0),_metric('💎 الماس',wallet['diamonds']??0),_metric('💰 الثروة',wealth['totalSupportedCoins']??wealth['total']??0),_metric('⭐ المستوى',wealth['currentLevel'] is Map ? (wealth['currentLevel']['name']??wealth['currentLevel']['id']??'-') : (wealth['currentLevel']??'-')),
        ]),
        _section('النمو والتفاعل',[
          _metric('🎁 الدعوات',refs['invited']??refs['referralCount']??0),_metric('🔗 نقرات الدعوة',refs['clicks']??0),_metric('🔔 غير المقروء',notes['unread']??0),_metric('🏆 VIP',levels['vip'] is List ? '${(levels['vip'] as List).length} مستويات' : 'متاح'),
        ]),
        _section('جاهزية المنصة',[
          _metric('🟢 API',health['ok']==true?'Online':'Check'),_metric('⚡ الإصدار',health['version']??'11.0'),_metric('🔐 الأمان','JWT + Rate Limit'),_metric('☁️ Live','Socket.IO'),
        ]),
        const SizedBox(height:8),
        const Text('طبقات المنتج',style:TextStyle(fontSize:19,fontWeight:FontWeight.w900)),const SizedBox(height:10),
        Wrap(spacing:10,runSpacing:10,children:const [
          _Pill('🎙 غرف صوتية'),_Pill('🎁 اقتصاد وهدايا'),_Pill('👑 VIP / SVIP'),_Pill('👨‍👩‍👧 عائلات'),_Pill('🎮 ألعاب ومهام'),_Pill('🏅 إنجازات'),_Pill('🤝 إحالات'),_Pill('🛡 إدارة وأمان'),_Pill('📊 تحليلات'),
        ]),
        const SizedBox(height:16),
        FilledButton.icon(onPressed:()=>context.push('/business-center'),icon:const Icon(Icons.insights),label:const Text('مركز الأعمال والتحليلات')),
        const SizedBox(height:24),
        Container(padding:const EdgeInsets.all(14),decoration:BoxDecoration(color:KibriyaColors.surface,borderRadius:BorderRadius.circular(18),border:Border.all(color:Colors.white10)),child:const Text('ملاحظة: هذه الشاشة تجمع بيانات الأنظمة الموجودة بالفعل، ولا تنشئ رصيدًا أو أرباحًا وهمية على الجهاز.',style:TextStyle(color:KibriyaColors.muted,height:1.5))),
      ]);
    }),
  );
}

Widget _section(String title,List<Widget> children)=>Padding(padding:const EdgeInsets.only(bottom:18),child:Column(crossAxisAlignment:CrossAxisAlignment.start,children:[Text(title,style:const TextStyle(fontSize:19,fontWeight:FontWeight.w900)),const SizedBox(height:10),GridView.count(shrinkWrap:true,physics:const NeverScrollableScrollPhysics(),crossAxisCount:2,childAspectRatio:2.05,crossAxisSpacing:10,mainAxisSpacing:10,children:children)]));
Widget _metric(String label,Object value)=>Container(padding:const EdgeInsets.all(12),decoration:BoxDecoration(color:KibriyaColors.surface,borderRadius:BorderRadius.circular(16),border:Border.all(color:Colors.white10)),child:Column(crossAxisAlignment:CrossAxisAlignment.start,mainAxisAlignment:MainAxisAlignment.center,children:[Text(label,style:const TextStyle(color:KibriyaColors.muted,fontSize:12)),const SizedBox(height:5),Text('$value',maxLines:1,overflow:TextOverflow.ellipsis,style:const TextStyle(fontWeight:FontWeight.w900,fontSize:15))]));
class _Pill extends StatelessWidget{final String text;const _Pill(this.text);@override Widget build(BuildContext c)=>Container(padding:const EdgeInsets.symmetric(horizontal:14,vertical:10),decoration:BoxDecoration(color:KibriyaColors.surface2,borderRadius:BorderRadius.circular(20)),child:Text(text,style:const TextStyle(fontWeight:FontWeight.w700)));}
