import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import '../core/providers.dart';
import '../core/theme.dart';

class NotificationsScreen extends ConsumerStatefulWidget { const NotificationsScreen({super.key}); @override ConsumerState<NotificationsScreen> createState()=>_NotificationsState(); }
class _NotificationsState extends ConsumerState<NotificationsScreen>{
  List<dynamic> items=[]; bool loading=true;
  @override void initState(){super.initState();_load();}
  Future<void> _load() async {try{final r=await ref.read(apiProvider).notifications();if(mounted)setState(()=>items=List<dynamic>.from(r['notifications']??[]));}finally{if(mounted)setState(()=>loading=false);}}
  @override Widget build(BuildContext context)=>Scaffold(appBar:AppBar(title:const Text('الإشعارات'),actions:[TextButton(onPressed:items.isEmpty?null:()async{await ref.read(apiProvider).markAllNotificationsRead();_load();},child:const Text('قراءة الكل'))]),body:loading?const Center(child:CircularProgressIndicator()):items.isEmpty?const Center(child:Text('مفيش إشعارات جديدة')):RefreshIndicator(onRefresh:_load,child:ListView.separated(padding:const EdgeInsets.all(14),itemCount:items.length,separatorBuilder:(_,__)=>const SizedBox(height:8),itemBuilder:(c,i){final n=items[i];final read=n['is_read']==true;return Dismissible(key:ValueKey('${n['id']}'),direction:DismissDirection.endToStart,onDismissed:(_)=>ref.read(apiProvider).deleteNotification('${n['id']}'),background:Container(alignment:Alignment.centerLeft,padding:const EdgeInsets.only(left:20),decoration:BoxDecoration(color:KibriyaColors.danger,borderRadius:BorderRadius.circular(18)),child:const Icon(Icons.delete_outline)),child:Card(color:read?KibriyaColors.surface:KibriyaColors.surface2,child:ListTile(onTap:read?null:(){ref.read(apiProvider).markNotificationRead('${n['id']}');setState(()=>n['is_read']=true);},leading:CircleAvatar(backgroundColor:KibriyaColors.gold.withOpacity(.16),child:Icon(n['type']=='gift'?Icons.card_giftcard:Icons.notifications_active,color:KibriyaColors.gold)),title:Text('${n['title']}',style:TextStyle(fontWeight:read?FontWeight.w500:FontWeight.w900)),subtitle:Text('${n['body']}'),trailing:read?null:const Icon(Icons.fiber_manual_record,size:10,color:KibriyaColors.violet))));})));
}
