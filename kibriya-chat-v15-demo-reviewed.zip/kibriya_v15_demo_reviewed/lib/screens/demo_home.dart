import 'package:flutter/material.dart';

class DemoHomeScreen extends StatelessWidget {
  const DemoHomeScreen({super.key});

  @override
  Widget build(BuildContext context) => Scaffold(
    appBar: AppBar(title: const Text('كبرياء شات • Demo')),
    body: ListView(padding: const EdgeInsets.all(16), children: [
      Container(height: 170, decoration: BoxDecoration(borderRadius: BorderRadius.circular(28), gradient: const LinearGradient(colors: [Color(0xFF5B1A2B), Color(0xFFBD7B24)])), child: Stack(children: [
        Positioned(right: 16, top: 16, child: ClipRRect(borderRadius: BorderRadius.circular(20), child: Image.asset('assets/branding/logo.jpg', width: 125, height: 125, fit: BoxFit.cover))),
        const Positioned(left: 18, top: 34, child: Text('ليالي كبرياء', style: TextStyle(fontSize: 30, fontWeight: FontWeight.w900))),
        const Positioned(left: 18, top: 82, child: Text('نسخة عرض للمشتري', style: TextStyle(fontSize: 16))),
      ])),
      const SizedBox(height: 20),
      const Text('الغرف الصوتية', style: TextStyle(fontSize: 21, fontWeight: FontWeight.w900)),
      const SizedBox(height: 10),
      ...['غرفة الملوك 👑','سهرة كبرياء 🎤','VIP Lounge 💎'].map((name) => Card(margin: const EdgeInsets.only(bottom: 10), child: ListTile(leading: const CircleAvatar(child: Icon(Icons.graphic_eq)), title: Text(name), subtitle: const Text('غرفة صوتية • 30 مقعدًا'), trailing: FilledButton(onPressed: () => showDialog(context: context, builder: (_) => AlertDialog(title: Text(name), content: const Text('هذه شاشة عرض Demo. الصوت الحقيقي والغرف الحية تعمل عند ربط Backend وZEGOCLOUD.'), actions: [TextButton(onPressed: () => Navigator.pop(context), child: const Text('إغلاق'))])), child: const Text('عرض'))))),
      const SizedBox(height: 8),
      Wrap(spacing: 10, runSpacing: 10, children: [
        _demoButton(context, Icons.card_giftcard, 'الهدايا', 'نظام هدايا وعملات'),
        _demoButton(context, Icons.workspace_premium, 'VIP / SVIP', 'مستويات ومظاهر'),
        _demoButton(context, Icons.business, 'الوكالات', 'مضيفون وعمولات'),
        _demoButton(context, Icons.admin_panel_settings, 'Admin', 'لوحة تحكم وإدارة'),
      ]),
      const SizedBox(height: 18),
      const Card(child: Padding(padding: EdgeInsets.all(16), child: Text('DEMO • البيانات الظاهرة تجريبية وليست بيانات إنتاج. النسخة الأصلية ومفاتيح الإنتاج تظل منفصلة.', style: TextStyle(fontWeight: FontWeight.w700)))),
    ]),
  );

  static Widget _demoButton(BuildContext context, IconData icon, String title, String body) => SizedBox(width: 165, child: Card(child: InkWell(onTap: () => showDialog(context: context, builder: (_) => AlertDialog(title: Text(title), content: Text(body), actions: [TextButton(onPressed: () => Navigator.pop(context), child: const Text('إغلاق'))])), child: Padding(padding: const EdgeInsets.all(14), child: Column(children: [Icon(icon, size: 34), const SizedBox(height: 8), Text(title, style: const TextStyle(fontWeight: FontWeight.w900)), const SizedBox(height: 4), Text(body, textAlign: TextAlign.center, style: const TextStyle(fontSize: 12, color: Colors.white60))])))));
}
