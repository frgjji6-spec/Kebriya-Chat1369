import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import '../core/providers.dart';

class BusinessCenterScreen extends ConsumerStatefulWidget {
  const BusinessCenterScreen({super.key});
  @override ConsumerState<BusinessCenterScreen> createState() => _BusinessCenterState();
}

class _BusinessCenterState extends ConsumerState<BusinessCenterScreen> {
  Map<String,dynamic>? analytics, ready, host; List<dynamic> events=[];
  bool loading=true;
  @override void initState(){super.initState(); _load();}
  Future<void> _load() async {
    try {
      final api=ref.read(apiProvider);
      final r=await Future.wait([api.adminAnalytics(),api.platformReady(),api.hostDashboard(),api.businessEvents()]);
      if(mounted)setState((){analytics=r[0] as Map<String,dynamic>;ready=r[1] as Map<String,dynamic>;host=r[2] as Map<String,dynamic>;events=List<dynamic>.from(r[3] as List);});
    } catch(e) {
      if(mounted) ScaffoldMessenger.of(context).showSnackBar(SnackBar(content:Text('مركز الأعمال يحتاج صلاحية Owner: $e')));
    } finally { if(mounted)setState(()=>loading=false); }
  }
  @override Widget build(BuildContext c)=>Scaffold(
    appBar:AppBar(title:const Text('مركز الأعمال • Premium'),actions:[IconButton(onPressed:_load,icon:const Icon(Icons.refresh))]),
    body:loading?const Center(child:CircularProgressIndicator()):RefreshIndicator(onRefresh:_load,child:ListView(padding:const EdgeInsets.all(14),children:[
      _hero(), const SizedBox(height:14),
      if(ready!=null)_readyCard(), const SizedBox(height:14),
      if(analytics!=null)_kpis(), const SizedBox(height:14), if(host!=null)_host(), const SizedBox(height:14), _events(), const SizedBox(height:14),
      _section('تشغيل تجاري',[
        _item(Icons.security,'الأمان','JWT + صلاحيات الإدارة + سجل العمليات'),
        _item(Icons.storage_rounded,'البيانات','PostgreSQL + معاملات اقتصادية مركزية'),
        _item(Icons.graphic_eq,'الصوت','غرف لحظية ومقاعد وإدارة مضيفين'),
        _item(Icons.insights,'التحليلات','DAU • غرف • هدايا • VIP • بلاغات'),
      ]),
    ])));

  Widget _hero()=>Container(padding:const EdgeInsets.all(20),decoration:BoxDecoration(borderRadius:BorderRadius.circular(26),gradient:const LinearGradient(colors:[Color(0xFF3C1630),Color(0xFF9A5B1E)])),child:const Column(crossAxisAlignment:CrossAxisAlignment.start,children:[Text('👑 كبرياء شات',style:TextStyle(fontSize:27,fontWeight:FontWeight.w900)),SizedBox(height:7),Text('Commercial Business Center',style:TextStyle(fontSize:15)),SizedBox(height:10),Text('مركز تشغيل وقياس المنتج من شاشة واحدة',style:TextStyle(fontSize:14))]));
  Widget _readyCard(){final checks=Map<String,dynamic>.from((ready!['checks']??{}) as Map);final ok=ready!['ready']==true;return Card(child:Padding(padding:const EdgeInsets.all(16),child:Column(crossAxisAlignment:CrossAxisAlignment.start,children:[Row(children:[Icon(ok?Icons.check_circle:Icons.warning_amber_rounded,color:ok?Colors.green:Colors.orange),const SizedBox(width:8),Text(ok?'النظام جاهز للتشغيل':'النظام يحتاج إعدادات',style:const TextStyle(fontWeight:FontWeight.w900,fontSize:18))]),const SizedBox(height:10),...checks.entries.map((e)=>ListTile(dense:true,contentPadding:EdgeInsets.zero,leading:Icon(e.value==true?Icons.verified:Icons.error_outline,color:e.value==true?Colors.green:Colors.red),title:Text('${e.key}'),trailing:Text(e.value==true?'OK':'غير جاهز')))])));
  Widget _kpis(){final a=analytics!;return Column(crossAxisAlignment:CrossAxisAlignment.start,children:[const Text('مؤشرات اليوم',style:TextStyle(fontSize:21,fontWeight:FontWeight.w900)),const SizedBox(height:8),Wrap(spacing:8,runSpacing:8,children:[_metric('DAU','${a['dau']??0}',Icons.people_alt_outlined),_metric('مستخدمون جدد','${a['newUsersToday']??0}',Icons.person_add_alt_1),_metric('غرف Live','${a['liveRooms']??0}',Icons.mic_none),_metric('هدايا','${a['todayGifts']??0}',Icons.card_giftcard),_metric('VIP','${a['vipUsers']??0}',Icons.workspace_premium),_metric('بلاغات مفتوحة','${a['openReports']??0}',Icons.flag_outlined)])]);}
  Widget _host(){final s=Map<String,dynamic>.from((host!['stats']??{}) as Map);final a=host!['agency'];final goals=List<dynamic>.from(host!['goals']??[]);return _section('🎙️ مركز المضيف',[_metric('دقائق الغرف','${s['room_minutes']??0}',Icons.timer_outlined),_metric('الهدايا','${s['gifts_received']??0}',Icons.card_giftcard),_metric('Coins الهدايا','${s['gift_coins']??0}',Icons.monetization_on),_metric('الزوار','${s['unique_visitors']??0}',Icons.people_outline),if(a!=null)ListTile(contentPadding:EdgeInsets.zero,leading:const CircleAvatar(child:Icon(Icons.business)),title:Text('${a['name']}',style:const TextStyle(fontWeight:FontWeight.w800)),subtitle:Text('الدور: ${a['role']} • عمولة ${a['commission_percent']}%')),if(goals.isNotEmpty)...goals.take(3).map((g)=>ListTile(contentPadding:EdgeInsets.zero,leading:const Icon(Icons.flag),title:Text('${g['title']}'),subtitle:Text('التقدم ${g['progress']}/${g['target_value']} • مكافأة ${g['reward_coins']} Coins'))]);}
  Widget _events(){return _section('🎉 الأحداث الحالية',events.isEmpty?[const ListTile(contentPadding:EdgeInsets.zero,title:Text('لا توجد أحداث منشورة حاليًا'))]:events.take(5).map((e)=>ListTile(contentPadding:EdgeInsets.zero,leading:const CircleAvatar(child:Icon(Icons.celebration)),title:Text('${e['title']}',style:const TextStyle(fontWeight:FontWeight.w800)),subtitle:Text('${e['description']??''}
مكافأة: ${e['reward_coins']??0} Coins • XP ${e['reward_xp']??0}')) .toList());}
  Widget _metric(String t,String v,IconData i)=>SizedBox(width:150,child:Card(child:Padding(padding:const EdgeInsets.all(14),child:Row(children:[Icon(i,size:25),const SizedBox(width:9),Expanded(child:Column(crossAxisAlignment:CrossAxisAlignment.start,children:[Text(v,style:const TextStyle(fontSize:21,fontWeight:FontWeight.w900)),Text(t,style:const TextStyle(fontSize:12))]))]))));
  Widget _section(String title,List<Widget> items)=>Card(child:Padding(padding:const EdgeInsets.all(14),child:Column(crossAxisAlignment:CrossAxisAlignment.start,children:[Text(title,style:const TextStyle(fontSize:20,fontWeight:FontWeight.w900)),const SizedBox(height:8),...items])));
  Widget _item(IconData i,String t,String s)=>ListTile(contentPadding:EdgeInsets.zero,leading:CircleAvatar(child:Icon(i)),title:Text(t,style:const TextStyle(fontWeight:FontWeight.w800)),subtitle:Text(s));
}
