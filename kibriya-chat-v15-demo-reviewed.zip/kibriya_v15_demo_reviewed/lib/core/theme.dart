import 'package:flutter/material.dart';

/// One visual system for Kibriya Chat.
/// Keep feature screens on these semantic colors instead of inventing new
/// palettes per screen.
class KibriyaColors {
  static const navy = Color(0xFF07111F);
  static const surface = Color(0xFF0E1A2B);
  static const surface2 = Color(0xFF142238);
  static const gold = Color(0xFFD7A84A);
  static const goldLight = Color(0xFFF2D18A);
  static const wine = Color(0xFF5B1A2B);
  static const violet = Color(0xFF9B6CFF);
  static const cyan = Color(0xFF4DE3FF);
  static const rose = Color(0xFFFF6FAE);
  static const emerald = Color(0xFF47E0B1);
  static const success = Color(0xFF39C98A);
  static const danger = Color(0xFFE85D75);
  static const text = Color(0xFFF7F8FC);
  static const muted = Color(0xFFAAB4C4);
}

class KibriyaTheme {
  static ThemeData dark() {
    final scheme = ColorScheme.fromSeed(
      seedColor: KibriyaColors.violet,
      brightness: Brightness.dark,
      surface: KibriyaColors.surface,
    ).copyWith(
      primary: KibriyaColors.gold,
      onPrimary: const Color(0xFF211600),
      secondary: KibriyaColors.cyan,
      surface: KibriyaColors.surface,
      surfaceContainerHighest: KibriyaColors.surface2,
      tertiary: KibriyaColors.rose,
      error: KibriyaColors.danger,
    );

    return ThemeData(
      useMaterial3: true,
      brightness: Brightness.dark,
      colorScheme: scheme,
      scaffoldBackgroundColor: KibriyaColors.navy,
      fontFamily: 'Arial',
      visualDensity: VisualDensity.adaptivePlatformDensity,
      appBarTheme: const AppBarTheme(
        backgroundColor: KibriyaColors.navy,
        foregroundColor: KibriyaColors.text,
        elevation: 0,
        centerTitle: false,
      ),
      cardTheme: CardThemeData(
        color: KibriyaColors.surface,
        surfaceTintColor: Colors.transparent,
        elevation: 0,
        margin: EdgeInsets.zero,
        shape: RoundedRectangleBorder(borderRadius: BorderRadius.all(Radius.circular(18))),
      ),
      inputDecorationTheme: InputDecorationTheme(
        filled: true,
        fillColor: KibriyaColors.surface,
        hintStyle: const TextStyle(color: KibriyaColors.muted),
        labelStyle: const TextStyle(color: KibriyaColors.muted),
        border: OutlineInputBorder(
          borderRadius: BorderRadius.circular(14),
          borderSide: const BorderSide(color: Colors.white12),
        ),
        enabledBorder: OutlineInputBorder(
          borderRadius: BorderRadius.circular(14),
          borderSide: const BorderSide(color: Colors.white12),
        ),
        focusedBorder: OutlineInputBorder(
          borderRadius: BorderRadius.circular(14),
          borderSide: const BorderSide(color: KibriyaColors.gold, width: 1.5),
        ),
      ),
      navigationBarTheme: const NavigationBarThemeData(
        backgroundColor: KibriyaColors.surface,
        indicatorColor: Color(0x335B1A2B),
        elevation: 0,
      ),
      snackBarTheme: SnackBarThemeData(
        behavior: SnackBarBehavior.floating,
        backgroundColor: KibriyaColors.surface2,
        shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(14)),
      ),
      filledButtonTheme: FilledButtonThemeData(
        style: FilledButton.styleFrom(
          backgroundColor: KibriyaColors.gold,
          foregroundColor: const Color(0xFF211600),
          minimumSize: const Size(0, 46),
          shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(14)),
        ),
      ),
    );
  }
}
